/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filesystemmanager;

/**
 *
 * @author emreyavuz
 */
import java.io.*;

public class FileSystemManager {
    
    
    
    static class MyLinkedList<T> {
        Node head;
        int size;
        
        class Node {
            T data;
            Node next;
            
            Node(T data) {
                this.data = data;
                this.next = null;
            }
        }
        
        void add(T item) {
            Node newNode = new Node(item);
            if (head == null) {
                head = newNode;
            } else {
                Node current = head;
                while (current.next != null) {
                    current = current.next;
                }
                current.next = newNode;
            }
            size++;
        }
        
        boolean remove(T item) {
            if (head == null) return false;
            
            if (head.data == item) {
                head = head.next;
                size--;
                return true;
            }
            
            Node current = head;
            while (current.next != null && current.next.data != item) {
                current = current.next;
            }
            
            if (current.next != null) {
                current.next = current.next.next;
                size--;
                return true;
            }
            return false;
        }
        
        T get(int index) {
            if (index < 0 || index >= size) return null;
            Node current = head;
            for (int i = 0; i < index; i++) {
                current = current.next;
            }
            return current.data;
        }
        
        int size() {
            return size;
        }
        
        boolean isEmpty() {
            return size == 0;
        }
        
        boolean contains(T item) {
            Node current = head;
            while (current != null) {
                if (current.data == item) return true;
                current = current.next;
            }
            return false;
        }
        
        
        Object[] toArray() {
            Object[] array = new Object[size];
            Node current = head;
            for (int i = 0; i < size; i++) {
                array[i] = current.data;
                current = current.next;
            }
            return array;
        }
    }
    
   
    static class MyHashMap {
        private static final int CAPACITY = 100;
        private Entry[] table;
        
        class Entry {
            String key;
            MyLinkedList<FSItem> value;
            Entry next;
            
            Entry(String key, MyLinkedList<FSItem> value) {
                this.key = key;
                this.value = value;
            }
        }
        
        MyHashMap() {
            table = new Entry[CAPACITY];
        }
        
        private int hash(String key) {
            int hash = 0;
            for (int i = 0; i < key.length(); i++) {
                hash = (31 * hash + key.charAt(i)) % CAPACITY;
            }
            return hash;
        }
        
        void put(String key, FSItem item) {
            int index = hash(key);
            
            if (table[index] == null) {
                MyLinkedList<FSItem> list = new MyLinkedList<>();
                list.add(item);
                table[index] = new Entry(key, list);
            } else {
                Entry current = table[index];
                while (current != null) {
                    if (current.key.equals(key)) {
                        current.value.add(item);
                        return;
                    }
                    if (current.next == null) break;
                    current = current.next;
                }
                MyLinkedList<FSItem> list = new MyLinkedList<>();
                list.add(item);
                current.next = new Entry(key, list);
            }
        }
        
        MyLinkedList<FSItem> get(String key) {
            int index = hash(key);
            Entry current = table[index];
            
            while (current != null) {
                if (current.key.equals(key)) {
                    return current.value;
                }
                current = current.next;
            }
            return null;
        }
        
        void remove(String key, FSItem item) {
            int index = hash(key);
            Entry current = table[index];
            Entry prev = null;
            
            while (current != null) {
                if (current.key.equals(key)) {
                    current.value.remove(item);
                    if (current.value.isEmpty()) {
                        if (prev == null) {
                            table[index] = current.next;
                        } else {
                            prev.next = current.next;
                        }
                    }
                    return;
                }
                prev = current;
                current = current.next;
            }
        }
        
        boolean containsKey(String key) {
            return get(key) != null;
        }
    }
    
   
    static class MyStack<T> {
        private Object[] items;
        private int top;
        private static final int INITIAL_CAPACITY = 10;
        
        MyStack() {
            items = new Object[INITIAL_CAPACITY];
            top = -1;
        }
        
        void push(T item) {
            if (top == items.length - 1) {
                resize();
            }
            items[++top] = item;
        }
        
        @SuppressWarnings("unchecked")
        T pop() {
            if (isEmpty()) return null;
            return (T) items[top--];
        }
        
        @SuppressWarnings("unchecked")
        T peek() {
            if (isEmpty()) return null;
            return (T) items[top];
        }
        
        boolean isEmpty() {
            return top == -1;
        }
        
        private void resize() {
            Object[] newArray = new Object[items.length * 2];
            for (int i = 0; i <= top; i++) {
                newArray[i] = items[i];
            }
            items = newArray;
        }
    }
    
    
    
    enum AccessLevel { USER, SYSTEM }
    
    static abstract class FSItem {
        String name;
        Directory parent;
        long size;
        long lastModified;
        AccessLevel access;
        
        FSItem(String name, long size, long lastModified, AccessLevel access) {
            this.name = name;
            this.size = size;
            this.lastModified = lastModified;
            this.access = access;
        }
        
        abstract boolean isDirectory();
        
        String getPath() {
            if (parent == null) return "\\" + name;
            String parentPath = parent.getPath();
            return parentPath + "\\" + name;
        }
    }
    
    static class FSFile extends FSItem {
        String extension;
        
        FSFile(String name, String extension, long size, long lastModified, AccessLevel access) {
            super(name, size, lastModified, access);
            this.extension = extension;
        }
        
        @Override
        boolean isDirectory() { 
            return false; 
        }
        
        @Override
        public String toString() {
            return String.format("[FILE] %s.%s | Size: %d bytes | Modified: %s | Access: %s",
                    name, extension, size, formatDate(lastModified), access);
        }
    }
    
    static class Directory extends FSItem {
        MyLinkedList<FSItem> children;
        MyHashMap nameIndex;
        
        Directory(String name, long lastModified, AccessLevel access) {
            super(name, 0L, lastModified, access);
            this.children = new MyLinkedList<>();
            this.nameIndex = new MyHashMap();
        }
        
        @Override
        boolean isDirectory() { 
            return true; 
        }
        
        void addChild(FSItem item) {
            children.add(item);
            item.parent = this;
            nameIndex.put(item.name.toLowerCase(), item);
            recalculateUpwards();
        }
        
        boolean removeChild(FSItem item) {
            boolean removed = children.remove(item);
            if (removed) {
                nameIndex.remove(item.name.toLowerCase(), item);
                item.parent = null;
                recalculateUpwards();
            }
            return removed;
        }
        
        MyLinkedList<FSItem> searchByNameInThisDir(String name) {
            MyLinkedList<FSItem> result = nameIndex.get(name.toLowerCase());
            if (result == null) {
                return new MyLinkedList<>(); 
            }
            return result;
        }
        
        void recalculate() {
            long totalSize = 0L;
            long latestDate = 0L;
            boolean hasAnyUser = false;
            
            Object[] childArray = children.toArray();
            for (int i = 0; i < childArray.length; i++) {
                FSItem child = (FSItem) childArray[i];
                totalSize += child.size;
                
                long childDate = child.isDirectory()  ? getLatestModificationRecursive((Directory) child) : child.lastModified;
                
                if (childDate > latestDate) {
                    latestDate = childDate;
                }
                
                if (child.isDirectory()) {
                    if (hasUserAccessRecursive((Directory) child)) {
                        hasAnyUser = true;
                    }
                } else {
                    if (child.access == AccessLevel.USER) {
                        hasAnyUser = true;
                    }
                }
            }
            
            this.size = totalSize;
            if (latestDate > 0) {
                this.lastModified = latestDate;
            }
            this.access = (children.isEmpty() || hasAnyUser) ? AccessLevel.USER : AccessLevel.SYSTEM;
        }
        
        private long getLatestModificationRecursive(Directory dir) {
            long latest = dir.lastModified;
            Object[] childArray = dir.children.toArray();
            for (int i = 0; i < childArray.length; i++) {
                FSItem child = (FSItem) childArray[i];
                long childDate = child.isDirectory() ? getLatestModificationRecursive((Directory) child)  : child.lastModified;
                
                if (childDate > latest) {
                    latest = childDate;
                }
            }
            return latest;
        }
        
        private boolean hasUserAccessRecursive(Directory dir) {
            Object[] childArray = dir.children.toArray();
            for (int i = 0; i < childArray.length; i++) {
                FSItem child = (FSItem) childArray[i];
                if (child.access == AccessLevel.USER) {
                    return true;
                }
                if (child.isDirectory()) {
                    if (hasUserAccessRecursive((Directory) child)) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        void recalculateUpwards() {
            Directory current = this;
            while (current != null) {
                current.recalculate();
                current = current.parent;
            }
        }
        
        @Override
        public String toString() {
            return String.format("[DIR] %s | Size: %d bytes | Modified: %s | Access: %s | Children: %d",
                    name, size, formatDate(lastModified), access, children.size());
        }
    }
    
    
    
    private Directory root;
    private Directory current;
    
    public static void main(String[] args) {
        FileSystemManager manager = new FileSystemManager();
        
        System.out.println("FILE SYSTEM MANAGER ");
        
        
        System.out.print("Enter filesystem.txt path (or press Enter for default): ");
        String path = readLine();
        if (path.trim().isEmpty()) {
            path = "filesystem.txt";
        }
        
        try {
            manager.loadFromFile(path);
            System.out.println("✓ File system loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Creating empty root directory...");
            manager.createDefaultRoot();
        }
        
        manager.runMenu();
    }
    
    
    
    private static BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
    
    private static String readLine() {
        try {
            return inputReader.readLine();
        } catch (IOException e) {
            return "";
        }
    }
    
   
    
    private static long readLong() {
        try {
            return Long.parseLong(readLine().trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }
    
    
    
    private static String repeatChar(char c, int count) {
        char[] chars = new char[count];
        for (int i = 0; i < count; i++) {
            chars[i] = c;
        }
        return new String(chars);
    }
    
    private static String formatDate(long timestamp) {
        // Basit tarih formatı
        long seconds = timestamp;
        long days = seconds / 86400;
        return "Day " + days;
    }
    
    
    
    private String[] splitString(String str, String delimiter) {
        
        int count = 1;
        int index = 0;
        while (true) {
            index = findIndex(str, delimiter, index);
            if (index == -1) break;
            count++;
            index += delimiter.length();
        }
        
        
        String[] result = new String[count];
        
       
        int start = 0;
        int end = findIndex(str, delimiter, 0);
        int arrayIndex = 0;
        
        while (end >= 0) {
            result[arrayIndex++] = substring(str, start, end);
            start = end + delimiter.length();
            end = findIndex(str, delimiter, start);
        }
       
        result[arrayIndex] = substring(str, start, str.length());
        
        return result;
    }
    
    private int findIndex(String str, String delimiter, int fromIndex) {
        if (fromIndex < 0) fromIndex = 0;
        if (fromIndex >= str.length()) return -1;
        
        
        for (int i = fromIndex; i <= str.length() - delimiter.length(); i++) {
            boolean found = true;
            for (int j = 0; j < delimiter.length(); j++) {
                if (str.charAt(i + j) != delimiter.charAt(j)) {
                    found = false;
                    break;
                }
            }
            if (found) return i;
        }
        return -1;
    }
    
    private String substring(String str, int start, int end) {
        if (start < 0) start = 0;
        if (end > str.length()) end = str.length();
        if (start >= end) return "";
        
        char[] chars = new char[end - start];
        for (int i = start; i < end; i++) {
            chars[i - start] = str.charAt(i);
        }
        return new String(chars);
    }
    
    
    
    private void loadFromFile(String filename) throws IOException {
        File file = new File(filename);
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filename);
        }
        
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        
        MyStack<Directory> dirStack = new MyStack<>();
        MyStack<Integer> indentStack = new MyStack<>();
        
        root = null;
        
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            
            int indent = countIndent(line);
            String trimmed = line.trim();
            trimmed = normalizeSeparators(trimmed);
            
            if (trimmed.startsWith("\\")) {
                String dirPart = trimmed.substring(1);
                String[] dirParts = splitString(dirPart, "##");
                String dirName = dirParts.length > 0 ? dirParts[0].trim() : "";
                if (dirName.isEmpty()) dirName = "root";
                
                Directory newDir = new Directory(dirName, System.currentTimeMillis() / 1000, AccessLevel.USER);
                
                if (dirStack.isEmpty()) {
                    root = newDir;
                    dirStack.push(newDir);
                    indentStack.push(indent);
                } else {
                    while (!indentStack.isEmpty() && indent <= indentStack.peek()) {
                        dirStack.pop();
                        indentStack.pop();
                    }
                    
                    Directory parent = dirStack.peek();
                    if (parent != null) {
                        parent.addChild(newDir);
                    }
                    
                    dirStack.push(newDir);
                    indentStack.push(indent);
                }
            } else {
                String[] parts = splitString(trimmed, "##");
                if (parts.length < 4) {
                    System.out.println("Warning: Skipping: " + trimmed);
                    continue;
                }
                
                String fullName = parts[0].trim();
                String dateStr = parts[1].trim();
                String sizeStr = parts[2].trim();
                String accessStr = parts[3].trim();
                
                dateStr = cleanDateString(dateStr);
                
                String fileName;
                String extension;
                int dotIndex = lastIndexOf(fullName, '.');
                if (dotIndex >= 0) {
                    fileName = substring(fullName, 0, dotIndex);
                    extension = substring(fullName, dotIndex + 1, fullName.length()).toLowerCase();
                } else {
                    fileName = fullName;
                    extension = "";
                }
                
                long date = parseDate(dateStr);
                long size = parseLong(sizeStr);
                
                AccessLevel access = accessStr.equalsIgnoreCase("SYSTEM")  ? AccessLevel.SYSTEM : AccessLevel.USER;
                
                FSFile newFile = new FSFile(fileName, extension, size, date, access);
                
                while (!indentStack.isEmpty() && indent <= indentStack.peek()) {
                    dirStack.pop();
                    indentStack.pop();
                }
                
                Directory parent = dirStack.peek();
                if (parent != null) {
                    parent.addChild(newFile);
                }
            }
        }
        
        reader.close();
        
        if (root == null) {
            createDefaultRoot();
        } else {
            current = root;
            root.recalculateUpwards();
        }
    }
    
    private int countIndent(String line) {
        int indentLevel = 0;
        int spaces = 0;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\t') {
                indentLevel++;
            } else if (c == ' ') {
                spaces++;
                if (spaces == 4) {
                    indentLevel++;
                    spaces = 0;
                }
            } else {
                break;
            }
        }
        return indentLevel;
    }
    
    private String normalizeSeparators(String line) {
        StringBuilder result = new StringBuilder();
        boolean inHash = false;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '#') {
                if (!inHash) {
                    result.append("##");
                    inHash = true;
                }
            } else {
                result.append(c);
                inHash = false;
            }
        }
        return result.toString();
    }
    
    private String cleanDateString(String dateStr) {
        int hashIndex = findIndex(dateStr, "#", 0);
        if (hashIndex >= 0) {
            return substring(dateStr, 0, hashIndex);
        }
        return dateStr;
    }
    
    private int lastIndexOf(String str, char ch) {
        for (int i = str.length() - 1; i >= 0; i--) {
            if (str.charAt(i) == ch) return i;
        }
        return -1;
    }
    
    private long parseDate(String dateStr) {
        try {
            
            String[] parts = splitString(dateStr, ".");
            if (parts.length == 3) {
                int day = parseInt(parts[0]);
                int month = parseInt(parts[1]);
                int year = parseInt(parts[2]);
                
                return (year - 1970) * 31536000L + (month - 1) * 2592000L + (day - 1) * 86400L;
            }
        } catch (Exception e) {
            
        }
        return System.currentTimeMillis() / 1000;
    }
    
    private int parseInt(String str) {
        try {
            int result = 0;
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (c >= '0' && c <= '9') {
                    result = result * 10 + (c - '0');
                } else {
                    break;
                }
            }
            return result;
        } catch (Exception e) {
            return 0;
        }
    }
    
    private long parseLong(String str) {
        try {
            long result = 0;
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (c >= '0' && c <= '9') {
                    result = result * 10 + (c - '0');
                } else {
                    break;
                }
            }
            return result;
        } catch (Exception e) {
            return 0L;
        }
    }
    
    private void createDefaultRoot() {
        root = new Directory("root", System.currentTimeMillis() / 1000, AccessLevel.USER);
        root.parent = null;
        current = root;
    }
    
  
    
    private void runMenu() {
        String menu = "\n" + repeatChar('=', 50) + "\n" + "           FILE SYSTEM MANAGEMENT MENU\n" +
                repeatChar('=', 50) + "\n" +
                "  1) Show current directory path\n" +
                "  2) Change to parent directory (..)\n" +
                "  3) Change to child directory\n" +
                "  4) Create new directory\n" +
                "  5) Create new file\n" +
                "  6) Delete directory\n" +
                "  7) Delete file\n" +
                "  8) Search by name (recursive)\n" +
                "  9) Search by extension (recursive)\n" +
                " 10) Search in current directory\n" +
                " 11) List current directory contents\n" +
                " 12) Print full tree structure\n" +
                "  0) Exit\n" +
                 repeatChar('=', 50) + "\n";
        
        while (true) {
            System.out.print(menu);
            System.out.print("Current: " + current.getPath() + "\n> ");
            String choice = readLine().trim();
            
            try {
                switch (choice) {
                    case "1": showCurrentPath(); break;
                    case "2": changeToParent(); break;
                    case "3": changeToChild(); break;
                    case "4": createDirectory(); break;
                    case "5": createFile(); break;
                    case "6": deleteDirectory(); break;
                    case "7": deleteFile(); break;
                    case "8": searchByName(); break;
                    case "9": searchByExtension(); break;
                    case "10": searchInCurrentDirectory(); break;
                    case "11": listContents(); break;
                    case "12": printTree(root, "", true); break;
                    case "0": 
                        System.out.println("Exiting. Goodbye!");
                        try {
                            inputReader.close();
                        } catch (IOException e) {
                            
                        }
                        return;
                    default: 
                        System.out.println("Invalid choice.");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
    
    
    
    private void showCurrentPath() {
        System.out.println("\nCurrent directory: " + current.getPath());
        System.out.println("Size: " + current.size + " bytes");
        System.out.println("Last Modified: " + formatDate(current.lastModified));
        System.out.println("Access Level: " + current.access);
    }
    
    private void changeToParent() {
        if (current.parent == null) {
            System.out.println("\nAlready at root.");
            return;
        }
        current = current.parent;
        System.out.println("\nChanged to: " + current.getPath());
    }
    
    private void changeToChild() {
        System.out.print("Enter directory name: ");
        String name = readLine().trim();
        
        MyLinkedList<FSItem> found = current.searchByNameInThisDir(name);
        if (found.isEmpty()) {
            System.out.println("\nNot found: " + name);
            return;
        }
        
        Directory targetDir = null;
        Object[] foundArray = found.toArray();
        for (int i = 0; i < foundArray.length; i++) {
            FSItem item = (FSItem) foundArray[i];
            if (item.isDirectory()) {
                targetDir = (Directory) item;
                break;
            }
        }
        
        if (targetDir == null) {
            System.out.println("\nNot a directory: " + name);
            return;
        }
        
        if (targetDir.access == AccessLevel.SYSTEM) {
            System.out.print("\nWARNING: SYSTEM directory. Proceed? (yes/no): ");
            String response = readLine().trim().toLowerCase();
            if (!response.equals("yes")) {
                System.out.println("Cancelled.");
                return;
            }
        }
        
        current = targetDir;
        System.out.println("\nChanged to: " + current.getPath());
    }
    
    private void createDirectory() {
        if (current.access != AccessLevel.USER) {
            System.out.println("\nCannot create directory in SYSTEM directory.");
            return;
        }

        System.out.print("Enter new directory name: ");
        String name = readLine().trim();
        
        if (name.isEmpty()) {
            System.out.println("\nDirectory name cannot be empty.");
            return;
        }

        if (!current.searchByNameInThisDir(name).isEmpty()) {
            System.out.println("\nName already exists: " + name);
            return;
        }

        Directory newDir = new Directory(name, System.currentTimeMillis() / 1000, AccessLevel.USER);
        current.addChild(newDir);
        System.out.println("\nCreated: " + newDir.getPath());
    }
    
    private void createFile() {
        if (current.access != AccessLevel.USER) {
            System.out.println("\nCannot create file in SYSTEM directory.");
            return;
        }

        System.out.print("Enter file name (without extension): ");
        String name = readLine().trim();
        
        if (name.isEmpty()) {
            System.out.println("\nFile name cannot be empty.");
            return;
        }

        System.out.print("Enter extension: ");
        String extension = readLine().trim().toLowerCase();

        System.out.print("Enter size in bytes: ");
        long size = readLong();

        FSFile newFile = new FSFile(name, extension, size, System.currentTimeMillis() / 1000, AccessLevel.USER);
        current.addChild(newFile);
        System.out.println("\nCreated: " + newFile.getPath() + "." + extension);
    }
    
    private void deleteDirectory() {
        System.out.print("Enter directory name to delete: ");
        String name = readLine().trim();

        MyLinkedList<FSItem> found = current.searchByNameInThisDir(name);
        Directory target = null;
        Object[] foundArray = found.toArray();
        for (int i = 0; i < foundArray.length; i++) {
            FSItem item = (FSItem) foundArray[i];
            if (item.isDirectory()) {
                target = (Directory) item;
                break;
            }
        }

        if (target == null) {
            System.out.println("\nDirectory not found: " + name);
            return;
        }

        if (target == root) {
            System.out.println("\nCannot delete root directory.");
            return;
        }

        if (containsSystemItems(target)) {
            System.out.println("\nCannot delete: contains SYSTEM items.");
            return;
        }

        current.removeChild(target);
        System.out.println("\nDeleted: " + name);
    }
    
    private boolean containsSystemItems(Directory dir) {
        if (dir.access == AccessLevel.SYSTEM) return true;
        
        Object[] childArray = dir.children.toArray();
        for (int i = 0; i < childArray.length; i++) {
            FSItem child = (FSItem) childArray[i];
            if (child.access == AccessLevel.SYSTEM) return true;
            if (child.isDirectory()) {
                if (containsSystemItems((Directory) child)) return true;
            }
        }
        return false;
    }
    
    private void deleteFile() {
        System.out.print("Enter file name (with or without extension): ");
        String input = readLine().trim();

        String fileName = input;
        String fileExt = null;

        int dotIndex = lastIndexOf(input, '.');
        if (dotIndex >= 0) {
            fileName = substring(input, 0, dotIndex);
            fileExt = substring(input, dotIndex + 1, input.length());
        }

        MyLinkedList<FSItem> found = current.searchByNameInThisDir(fileName);
        FSFile target = null;
        
        Object[] foundArray = found.toArray();
        for (int i = 0; i < foundArray.length; i++) {
            FSItem item = (FSItem) foundArray[i];
            if (!item.isDirectory()) {
                FSFile file = (FSFile) item;
                if (fileExt == null || file.extension.equalsIgnoreCase(fileExt)) {
                    target = file;
                    break;
                }
            }
        }

        if (target == null) {
            System.out.println("\nFile not found: " + input);
            return;
        }

        if (target.access == AccessLevel.SYSTEM) {
            System.out.println("\nCannot delete SYSTEM file.");
            return;
        }

        current.removeChild(target);
        System.out.println("\nDeleted: " + target.name + "." + target.extension);
    }
    
    private void searchByName() {
        System.out.print("Enter name to search: ");
        String query = readLine().trim().toLowerCase();

        MyLinkedList<FSItem> results = new MyLinkedList<>();
        searchByNameRecursive(current, query, results);

        if (results.isEmpty()) {
            System.out.println("\nNo matches found for: " + query);
        } else {
            System.out.println("\nSearch Results ");
            Object[] resultsArray = results.toArray();
            for (int i = 0; i < resultsArray.length; i++) {
                FSItem item = (FSItem) resultsArray[i];
                if (item.isDirectory()) {
                    System.out.println("[DIR]  " + item.getPath());
                } else {
                    FSFile file = (FSFile) item;
                    System.out.println("[FILE] " + item.getPath() + "." + file.extension);
                }
            }
            System.out.println("Total: " + results.size() + " item(s)");
        }
    }
    
    private void searchByNameRecursive(Directory dir, String query, MyLinkedList<FSItem> results) {
        Object[] childArray = dir.children.toArray();
        for (int i = 0; i < childArray.length; i++) {
            FSItem child = (FSItem) childArray[i];
            if (child.name.toLowerCase().contains(query)) {
                results.add(child);
            }
            if (child.isDirectory()) {
                searchByNameRecursive((Directory) child, query, results);
            }
        }
    }
    
    private void searchByExtension() {
        System.out.print("Enter extension to search: ");
        String extension = readLine().trim().toLowerCase();

        MyLinkedList<FSFile> results = new MyLinkedList<>();
        searchByExtensionRecursive(current, extension, results);

        if (results.isEmpty()) {
            System.out.println("\nNo files with extension: ." + extension);
        } else {
            System.out.println("\n Search Results ");
            Object[] resultsArray = results.toArray();
            for (int i = 0; i < resultsArray.length; i++) {
                FSFile file = (FSFile) resultsArray[i];
                System.out.println("[FILE] " + file.getPath() + "." + file.extension + " (Size: " + file.size + " bytes)");
            }
            System.out.println("Total: " + results.size() + " file(s)");
        }
    }
    
    private void searchByExtensionRecursive(Directory dir, String extension, MyLinkedList<FSFile> results) {
        Object[] childArray = dir.children.toArray();
        for (int i = 0; i < childArray.length; i++) {
            FSItem child = (FSItem) childArray[i];
            if (!child.isDirectory()) {
                FSFile file = (FSFile) child;
                if (file.extension.equalsIgnoreCase(extension)) {
                    results.add(file);
                }
            } else {
                searchByExtensionRecursive((Directory) child, extension, results);
            }
        }
    }
    
    private void searchInCurrentDirectory() {
        System.out.print("Enter exact name to search: ");
        String name = readLine().trim();

        MyLinkedList<FSItem> found = current.searchByNameInThisDir(name);

        if (found.isEmpty()) {
            System.out.println("\nNot found in current directory: " + name);
        } else {
            System.out.println("\nFound in Current Directory ");
            Object[] foundArray = found.toArray();
            for (int i = 0; i < foundArray.length; i++) {
                FSItem item = (FSItem) foundArray[i];
                System.out.println(item);
            }
        }
    }
    
    private void listContents() {
        if (current.access != AccessLevel.USER) {
            System.out.println("\nCannot list SYSTEM directory.");
            return;
        }

        if (current.children.isEmpty()) {
            System.out.println("\nDirectory is empty.");
            return;
        }

        System.out.println("\n=== Contents of " + current.getPath() + " ===");
        Object[] childArray = current.children.toArray();
        for (int i = 0; i < childArray.length; i++) {
            FSItem item = (FSItem) childArray[i];
            if (item.isDirectory()) {
                System.out.printf("[DIR]  %-30s | Size: %10d bytes | Access: %s%n",
         item.name, item.size, item.access);
            } else {
                FSFile file = (FSFile) item;
                System.out.printf("[FILE] %-30s | Size: %10d bytes | Access: %s%n",
        file.name + "." + file.extension, file.size, file.access);
            }
        }
        System.out.println("Total: " + current.children.size() + " item(s)");
    }
    
    private void printTree(Directory dir, String indent, boolean isLast) {
        String marker = isLast ? "|__ " : "|-- ";
        System.out.println(indent + marker + "[DIR] " + dir.name + " (Size: " + dir.size + " bytes, Access: " + dir.access + ")");
        
        String newIndent = indent + (isLast ? "    " : "|   ");
        
        Object[] childArray = dir.children.toArray();
        for (int i = 0; i < childArray.length; i++) {
            FSItem child = (FSItem) childArray[i];
            boolean childIsLast = (i == childArray.length - 1);
            
            if (child.isDirectory()) {
                printTree((Directory) child, newIndent, childIsLast);
            } else {
                FSFile file = (FSFile) child;
                String childMarker = childIsLast ? "|__ " : "|-- ";
                System.out.println(newIndent + childMarker + "[FILE] " + file.name + "." + 
                file.extension + " (" + file.size + " bytes, Access: " + file.access + ")");
            }
        }
    }
}