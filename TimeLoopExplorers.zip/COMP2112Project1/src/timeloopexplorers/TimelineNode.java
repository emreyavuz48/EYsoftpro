/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */
public class TimelineNode {
    final GameState state;
    TimelineNode parent;
    DoubleLinkedList<TimelineNode> children;
    final String action;
    final String branchId;
    final Explorer actor;

    public TimelineNode(String action, Explorer actor, GameState state, TimelineNode parent) {
        this.action = action;
        this.actor = actor;
        this.state = state;
        this.parent = parent;
        this.children = new DoubleLinkedList<>();
        
        if (parent == null) {
         this.branchId = "MAIN"; 
        } else {
           this.branchId = parent.branchId + "." + (parent.children.size() + 1);
        }
    }

    public void addChild(TimelineNode child) {
        this.children.add(child);
    }
}