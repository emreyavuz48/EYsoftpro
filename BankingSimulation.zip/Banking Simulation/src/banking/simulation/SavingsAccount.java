/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking.simulation;

public class SavingsAccount extends Account {
    private double interestRate;
    private String accountStatus;

    public SavingsAccount(int accountNumber, double balance, Customer owner, double interestRate, String accountStatus) {
        super(accountNumber, balance, owner);
        this.interestRate = interestRate;
        this.accountStatus = accountStatus;
    }

    @Override
    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }

    @Override
    public void withdraw(double amount) {
        setBalance(getBalance() - amount);
    }

    @Override
    public void transfer(Account destinationAccount, double amount) {
        withdraw(amount);
        destinationAccount.deposit(amount);
    }
}