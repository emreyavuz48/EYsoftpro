/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking.simulation;

public class InstitutionalCustomer extends Customer {
    private String typeOfInstitution;
    private String industrySector;
    private double annualRevenue;

    public InstitutionalCustomer(int customerId, String name, String address, String contact, String typeOfInstitution, String industrySector, double annualRevenue) {
        super(customerId, name, address, contact);
        this.typeOfInstitution = typeOfInstitution;
        this.industrySector = industrySector;
        this.annualRevenue = annualRevenue;
    }

    @Override
    public void updateContact(String newContact) {
        setContact(newContact);
    }
}