import java.io.*;
import java.util.*;

public class CityGraph {
    private HashMap<String, Integer> cityToIndex;
    private HashMap<Integer, String> indexToCity;
    private ArrayList<ArrayList<Pair<Integer, Integer>>> adjacencyList;

    public CityGraph() {
        cityToIndex = new HashMap<>();
        indexToCity = new HashMap<>();
        adjacencyList = new ArrayList<>();
    }

    public void readGraphFromFile(String filename) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        int index = 0;

        while ((line = br.readLine()) != null) {
            String[] parts = line.split("->");
            String city = parts[0].trim();
            if (!cityToIndex.containsKey(city)) {
                cityToIndex.put(city, index);
                indexToCity.put(index, city);
                adjacencyList.add(new ArrayList<>());
                index++;
            }

            if (parts.length > 1) {
                String[] edges = parts[1].split(",");
                for (String edge : edges) {
                    String[] edgeParts = edge.trim().split(":");
                    String destCity = edgeParts[0].trim();
                    int weight = Integer.parseInt(edgeParts[1].trim());

                    if (!cityToIndex.containsKey(destCity)) {
                        cityToIndex.put(destCity, index);
                        indexToCity.put(index, destCity);
                        adjacencyList.add(new ArrayList<>());
                        index++;
                    }

                    adjacencyList.get(cityToIndex.get(city)).add(new Pair<>(cityToIndex.get(destCity), weight));
                }
            }
        }
        br.close();
    }

    public boolean isThereAPath(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) return false;

        int start = cityToIndex.get(v1);
        int end = cityToIndex.get(v2);
        boolean[] visited = new boolean[adjacencyList.size()];
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.poll();
            if (current == end) return true;

            visited[current] = true;
            for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
                if (!visited[neighbor.getKey()]) queue.add(neighbor.getKey());
            }
        }
        return false;
    }

    public void bfsFromTo(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) {
            System.out.println("Cities not found.");
            return;
        }

        int start = cityToIndex.get(v1);
        int end = cityToIndex.get(v2);
        boolean[] visited = new boolean[adjacencyList.size()];
        Queue<List<Integer>> queue = new LinkedList<>();
        queue.add(Collections.singletonList(start));

        while (!queue.isEmpty()) {
            List<Integer> path = queue.poll();
            int lastNode = path.get(path.size() - 1);

            if (lastNode == end) {
                printPathWithWeights(path);
                return;
            }

            if (!visited[lastNode]) {
                visited[lastNode] = true;
                for (Pair<Integer, Integer> neighbor : adjacencyList.get(lastNode)) {
                    if (!visited[neighbor.getKey()]) {
                        List<Integer> newPath = new ArrayList<>(path);
                        newPath.add(neighbor.getKey());
                        queue.add(newPath);
                    }
                }
            }
        }
        System.out.println("No path found.");
    }
    public int numberOfSimplePaths(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) return 0;

        int start = cityToIndex.get(v1);
        int end = cityToIndex.get(v2);
        boolean[] visited = new boolean[adjacencyList.size()];
        return countSimplePathsDFS(start, end, visited);
    }

    private int countSimplePathsDFS(int current, int end, boolean[] visited) {
        if (current == end) return 1;

        visited[current] = true;
        int count = 0;
        for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
            if (!visited[neighbor.getKey()]) {
                count += countSimplePathsDFS(neighbor.getKey(), end, visited);
            }
        }
        visited[current] = false; // Backtrack
        return count;
    }

    public boolean isThereACycle(String v1) {
        if (!cityToIndex.containsKey(v1)) return false;

        int start = cityToIndex.get(v1);
        boolean[] visited = new boolean[adjacencyList.size()];
        return detectCycleDFS(start, -1, visited);
    }

    private boolean detectCycleDFS(int current, int parent, boolean[] visited) {
        visited[current] = true;

        for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
            if (!visited[neighbor.getKey()]) {
                if (detectCycleDFS(neighbor.getKey(), current, visited)) return true;
            } else if (neighbor.getKey() != parent) {
                return true; // Cycle detected
            }
        }
        return false;
    }

    public int numberOfVerticesInComponent(String v1) {
        if (!cityToIndex.containsKey(v1)) return 0;

        int start = cityToIndex.get(v1);
        boolean[] visited = new boolean[adjacencyList.size()];
        return countVerticesDFS(start, visited);
    }

    private int countVerticesDFS(int current, boolean[] visited) {
        visited[current] = true;
        int count = 1;

        for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
            if (!visited[neighbor.getKey()]) {
                count += countVerticesDFS(neighbor.getKey(), visited);
            }
        }
        return count;
    }

    public boolean areTheyAdjacent(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) return false;

        int vertex1 = cityToIndex.get(v1);
        int vertex2 = cityToIndex.get(v2);

        for (Pair<Integer, Integer> neighbor : adjacencyList.get(vertex1)) {
            if (neighbor.getKey() == vertex2) return true;
        }
        return false;
    }

    public void dfsFromTo(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) {
            System.out.println("Cities not found.");
            return;
        }

        int start = cityToIndex.get(v1);
        int end = cityToIndex.get(v2);
        boolean[] visited = new boolean[adjacencyList.size()];
        List<Integer> path = new ArrayList<>();
        path.add(start);

        if (dfsRecursive(start, end, visited, path)) {
            printPathWithWeights(path);
        } else {
            System.out.println("No path found.");
        }
    }

    private boolean dfsRecursive(int current, int end, boolean[] visited, List<Integer> path) {
        if (current == end) return true;

        visited[current] = true;
        for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
            if (!visited[neighbor.getKey()]) {
                path.add(neighbor.getKey());
                if (dfsRecursive(neighbor.getKey(), end, visited, path)) return true;
                path.remove(path.size() - 1); // Backtrack
            }
        }
        visited[current] = false;
        return false;
    }


    public int whatIsShortestPathLength(String v1, String v2) {
        if (!cityToIndex.containsKey(v1) || !cityToIndex.containsKey(v2)) {
            System.out.println(v1 + " --x-- " + v2);
            return -1;
        }

        int start = cityToIndex.get(v1);
        int end = cityToIndex.get(v2);
        int[] distances = new int[adjacencyList.size()];
        Arrays.fill(distances, Integer.MAX_VALUE);
        distances[start] = 0;

        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (Pair<Integer, Integer> neighbor : adjacencyList.get(current)) {
                int nextNode = neighbor.getKey();
                int weight = neighbor.getValue();

                if (distances[current] + weight < distances[nextNode]) {
                    distances[nextNode] = distances[current] + weight;
                    queue.add(nextNode);
                }
            }
        }

        if (distances[end] == Integer.MAX_VALUE) {
            System.out.println(v1 + " --x-- " + v2);
            return -1;
        }

        return distances[end];
    }

    public List<String> neighbors(String v1) {
        if (!cityToIndex.containsKey(v1)) return Collections.emptyList();

        int vertex = cityToIndex.get(v1);
        List<String> neighbors = new ArrayList<>();
        for (Pair<Integer, Integer> neighbor : adjacencyList.get(vertex)) {
            neighbors.add(indexToCity.get(neighbor.getKey()));
        }
        return neighbors;
    }

    public List<String> highestDegree() {
        int maxDegree = 0;
        List<String> highestDegreeCities = new ArrayList<>();

        for (int i = 0; i < adjacencyList.size(); i++) {
            int degree = adjacencyList.get(i).size();
            if (degree > maxDegree) {
                maxDegree = degree;
                highestDegreeCities.clear();
                highestDegreeCities.add(indexToCity.get(i));
            } else if (degree == maxDegree) {
                highestDegreeCities.add(indexToCity.get(i));
            }
        }
        return highestDegreeCities;
    }

    public boolean isDirected() {
        for (int i = 0; i < adjacencyList.size(); i++) {
            for (Pair<Integer, Integer> edge : adjacencyList.get(i)) {
                int neighbor = edge.getKey();
                boolean reverseEdgeExists = false;

                for (Pair<Integer, Integer> reverseEdge : adjacencyList.get(neighbor)) {
                    if (reverseEdge.getKey() == i && reverseEdge.getValue().equals(edge.getValue())) {
                        reverseEdgeExists = true;
                        break;
                    }
                }

                if (!reverseEdgeExists) return true;
            }
        }
        return false;
    }

    private void printPathWithWeights(List<Integer> path) {
        int totalWeight = 0;
        for (int i = 0; i < path.size() - 1; i++) {
            int from = path.get(i);
            int to = path.get(i + 1);
            int weight = adjacencyList.get(from).stream()
                    .filter(p -> p.getKey() == to)
                    .findFirst().get().getValue();
            totalWeight += weight;
            System.out.print(indexToCity.get(from) + " --(" + weight + ")--> ");
        }
        System.out.println(indexToCity.get(path.get(path.size() - 1)) + " | Total Weight: " + totalWeight);
    }



}
