import java.util.Random;
import java.util.Scanner;
import java.util.*;
public class MessageTransferLine {
    Node head;
    Node tail;
    int size;

    public MessageTransferLine() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    public void addStudent(Student student) {
        Node newNode = new Node(student);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
        }
        size++;
    }

    public void simulateMessageTransfer(String initialMessage, List<Integer> hubIndexes, String initialDirection) {
        boolean movingRight = initialDirection.equals("right");
        Node current = head;
        Random rand = new Random();

        // Randomly choose a starting student
        int startIndex = rand.nextInt(size);
        for (int i = 0; i < startIndex; i++) {
            current = current.next;
        }

        while (true) {
            // Pass the message
            current.student.countCommonLetters(initialMessage);

            // Check if current student is a hub
            int currentIndex = getIndex(current);
            if (hubIndexes.contains(currentIndex)) {
                System.out.println("Hub student " + current.student.name + " received the message.");
                // Ask for a new message
                Scanner scanner = new Scanner(System.in);
                System.out.print("Enter a new message: ");
                initialMessage = scanner.nextLine();
                // Change direction
                movingRight = !movingRight;
            }

            // Randomly pass the message to another student
            int k = rand.nextInt(5) + 1; // Random number between 1 and 5
            if (movingRight) {
                current = moveRight(current, k);
            } else {
                current = moveLeft(current, k);
            }

            // Break condition: all students have been visited
            if (allStudentsVisited()) {
                break;
            }
        }
    }

    public Node moveRight(Node current, int k) {
        for (int i = 0; i < k && current != null; i++) {
            current = current.next;
            if (current == null) {
                break;
            }
        }
        return current;
    }

    public Node moveLeft(Node current, int k) {
        for (int i = 0; i < k && current != null; i++) {
            current = current.previous;
            if (current == null) {
                break;
            }
        }
        return current;
    }

    public int getIndex(Node current) {
        int index = 0;
        Node temp = head;
        while (temp != null) {
            if (temp == current) {
                return index;
            }
            index++;
            temp = temp.next;
        }
        return -1; // Not found
    }

    public boolean allStudentsVisited() {
        Node current = head;
        while (current != null) {
            if (current.student.letterCount == 0) {
                return false;
            }
            current = current.next;
        }
        return true;
    }
}
