public class Node {
    char[] name;
    int nameLength;
    Node next;
    Node previous;
    Student student;
    public Node(String name) {
        this.name = name.toCharArray();
        this.nameLength = this.name.length;
        this.next = null;
        this.previous=null;
    }

    public Node(Student student){
        this.student=student;
        this.next = null;
        this.previous=null;

    }
    public void loseLetter() {
        if (nameLength > 0) {
            nameLength--; // Reduce the length to remove a letter
        }
    }

    public boolean isEliminated() {
        return nameLength == 0;
    }

    public String getCurrentName() {
        return new String(name, 0, nameLength);
    }
}
