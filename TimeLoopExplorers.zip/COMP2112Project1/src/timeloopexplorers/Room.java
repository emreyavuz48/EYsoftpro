/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */
public class Room {
    final int id;
    String eventType;
    boolean visited;
    
    public Room(int id) {
        this.id = id;
        this.eventType = "Unknown";
        this.visited = false;
    }
    
    public Room copy() {
        Room copy = new Room(this.id);
        copy.eventType = this.eventType;
        copy.visited = this.visited;
        return copy;
    }
    
    public void setEvent(String event) {
        this.eventType = event;
        this.visited = true;
    }
    
    @Override
    public String toString() {
        return "Room " + id + " [" + eventType + "]" + (visited ? " (visited)" : "");
    }
}