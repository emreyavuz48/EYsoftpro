/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking.simulation;

public class IndividualCustomer extends Customer {
    private String gender;
    private String identificationInformation;
    private String occupation;

    public IndividualCustomer(int customerId, String name, String address, String contact, String gender, String identificationInformation, String occupation) {
        super(customerId, name, address, contact);
        this.gender = gender;
        this.identificationInformation = identificationInformation;
        this.occupation = occupation;
    }

    @Override
    public void updateContact(String newContact) {
        setContact(newContact);
    }
}