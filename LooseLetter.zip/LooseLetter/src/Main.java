import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        CircularLinkedList players = new CircularLinkedList();
        ArrayList<String> names = new ArrayList<>();
        MessageTransferLine messageLine = new MessageTransferLine();
        List<Student> students = new ArrayList<>();
        // Step 1: Read names from file
        try (Scanner fileScanner = new Scanner(new File("/path/to/your/names.txt"))) {
            while (fileScanner.hasNextLine()) {
                names.add(fileScanner.nextLine().trim());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            return;
        }

        // Randomly select names and add to the circular list
        Random random = new Random();
        int N = names.size();
        for (int i = 0; i < N; i++) {
            players.add(names.get(i));
        }

        // Step 2: Game loop
        Node currentNode = players.head;
        while (!players.hasOnePlayerLeft()) {
            int k = random.nextInt(N) + 1; // Generate random k between 1 and N
            currentNode = players.getNode(k - 1); // Move k steps

            System.out.println("k = " + k + ", selected player: " + currentNode.getCurrentName());
            currentNode.loseLetter(); // Lose a letter
            players.display(currentNode); // Display current state

            if (currentNode.isEliminated()) {
                System.out.println("Player " + new String(currentNode.name) + " is eliminated!");
                // Remove player
                Node temp = players.head;
                while (temp.next != currentNode) {
                    temp = temp.next;
                }
                players.remove(temp, currentNode);
                currentNode = temp.next; // Move to next player
            } else {
                currentNode = currentNode.next; // Continue to next player
            }
        }

        System.out.println("Winner is: " + players.getWinner());

        // Read names from file
        try (BufferedReader br = new BufferedReader(new FileReader("names.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                students.add(new Student(line.trim()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Randomly shuffle students
        Collections.shuffle(students);
        for (Student student : students) {
            messageLine.addStudent(student);
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of hub students (M): ");
        int M = scanner.nextInt();
        Set<Integer> hubIndexes = new HashSet<>();
        Random rand = new Random();

        while (hubIndexes.size() < M) {
            hubIndexes.add(rand.nextInt(30)); // Assuming we have 30 students
        }

        // Get the initial message
        System.out.print("Enter the initial message: ");
        scanner.nextLine(); // Consume newline
        String initialMessage = scanner.nextLine();

        // Randomly choose initial direction
        String initialDirection = rand.nextBoolean() ? "right" : "left";

        // Start simulation
        messageLine.simulateMessageTransfer(initialMessage, new ArrayList<>(hubIndexes), initialDirection);

        // Print final letter counts
        for (Node n = messageLine.head; n != null; n = n.next) {
            System.out.println(n.student.name + " has a letter count of: " + n.student.letterCount);
        }

    }


}