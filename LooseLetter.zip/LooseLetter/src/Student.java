public class Student {
    String name;
    int letterCount;

    public Student(String name) {
        this.name = name;
        this.letterCount = 0;
    }

    public void countCommonLetters(String message) {
        for (char ch : message.toCharArray()) {
            if (name.contains(String.valueOf(ch))) {
                letterCount++;
            }
        }
    }
}
