/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking.simulation;

public class CheckingAccount extends Account {
    private boolean debitCard;
    private boolean atmAccess;
    private boolean onlineBankingAccess;

    public CheckingAccount(int accountNumber, double balance, Customer owner, boolean debitCard, boolean atmAccess, boolean onlineBankingAccess) {
        super(accountNumber, balance, owner);
        this.debitCard = debitCard;
        this.atmAccess = atmAccess;
        this.onlineBankingAccess = onlineBankingAccess;
    }

    @Override
    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }

    @Override
    public void withdraw(double amount) {
        setBalance(getBalance() - amount);
    }

    @Override
    public void transfer(Account destinationAccount, double amount) {
        withdraw(amount);
        destinationAccount.deposit(amount);
    }
}