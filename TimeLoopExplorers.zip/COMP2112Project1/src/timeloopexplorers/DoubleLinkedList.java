/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 * @param <T>
 */
public class DoubleLinkedList<T> {
    DoubleNode<T> head;
    DoubleNode<T> tail;
    private int size = 0;
    private boolean isCircular = false;
    
    public void add(T data) {
        DoubleNode<T> newNode = new DoubleNode<>(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }
    
    public boolean contains(T data) {
        DoubleNode<T> current = head;
        int checked = 0;
        while (current != null && (!isCircular || checked < size)) {
            if (current.data != null && current.data.equals(data)) return true;
            current = current.next;
            checked++;
            if (isCircular && current == head) break;
        }
        return false;
    }
    
    public void remove(T data) {
        if (head == null) return;
        
        DoubleNode<T> current = head;
        int checked = 0;
        while (current != null && (!isCircular || checked < size)) {
            if (current.data != null && current.data.equals(data)) {
                if (size == 1) {
                    head = tail = null;
                } else {
                    if (current.prev != null) current.prev.next = current.next;
                    if (current.next != null) current.next.prev = current.prev;
                    if (current == head) head = current.next;
                    if (current == tail) tail = current.prev;
                }
                size--;
                return;
            }
            current = current.next;
            checked++;
            if (isCircular && current == head) break;
        }
    }
    
    public boolean isEmpty() { return size == 0; }
    public int size() { return size; }
    
    public void makeCircular() {
        if (head != null && tail != null) {
            tail.next = head;
            head.prev = tail;
            isCircular = true;
        }
    }
}