/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */

import java.util.Random;
import java.util.Scanner;

public class TimeLoopExplorers {
    private DoubleLinkedList<Explorer> explorers;
    private DoubleNode<Explorer> currentExplorer;
    private Timeline timeline;
    private DoubleLinkedList<Room> rooms;
    private Random rand;
    private Scanner sc;
    private int roomNumber, turnNumber, nextStone;
    private boolean forward, running;
    private String lastEventDescription;
    
    public TimeLoopExplorers() {
        explorers = new DoubleLinkedList<>();
        rooms = new DoubleLinkedList<>();
        rand = new Random();
        sc = new Scanner(System.in);
        roomNumber = 1; turnNumber = 1; nextStone = 1;
        forward = true; running = true;
        lastEventDescription = "";
        initialize();
    }
    
    private void initialize() {
        System.out.println(" TIME LOOP EXPLORERS ");
        System.out.println("Escape the ancient ruin by using Echo Stones in sequence 1->2->3->4->5!\n");
        
        System.out.print("Number of explorers (3-5): ");
        int n = getIntInput(3, 5);
        
        for (int i = 1; i <= n; i++) {
            System.out.print("Explorer " + i + " name: ");
            explorers.add(new Explorer(sc.nextLine()));
        }
        
        explorers.makeCircular();
        currentExplorer = explorers.head;
        
        rooms.add(new Room(roomNumber));
        
        GameState startState = new GameState(roomNumber, nextStone, forward, turnNumber, 
    "Game begins", explorers, rooms, currentExplorer);
        timeline = new Timeline(startState);
        
        System.out.println("\n Game started! Find Paradox Shards to manipulate timelines!");
    }
    
    public void play() {
        while (running && !gameOver()) {
            Explorer e = currentExplorer.data;
            if (e.alive) {
                displayTurn(e);
                processChoice(getChoice(e), e);
                turnNumber++;
            } else {
                System.out.println( e.name + " is dead, skipping turn...");
            }
            
            if (running) {
                nextTurn();
            }
        }
        
        printGameSummary();
        sc.close();
    }
    
    private void printGameSummary() {
        String stars = "";
        for (int i = 0; i < 50; i++) {
            stars += "=";
        }
        
        System.out.println("\n" + stars);
        System.out.println("TIME LOOP EXPLORERS - GAME SUMMARY");
        System.out.println(stars);
        
        int totalTreasure = 0;
        int aliveExplorers = 0;
        int totalStonesUsed = nextStone - 1;
        
        DoubleNode<Explorer> current = explorers.head;
        while (current != null) {
            totalTreasure += current.data.treasure;
            if (current.data.alive) aliveExplorers++;
            current = current.next;
        }
        
        System.out.println("Final Statistics:");
        System.out.println(" Rooms Explored: " + rooms.size());
        System.out.println(" Total Treasure Collected: " + totalTreasure);
        System.out.println(" Echo Stones Used: " + totalStonesUsed + "/5");
        System.out.println(" Survivors: " + aliveExplorers + "/" + explorers.size());
        System.out.println(" Total Turns: " + (turnNumber - 1));
        System.out.println(" Timeline Branches: " + (timeline.countBranches() + 1));
        
        if (nextStone > 5) {
            System.out.println("\n VICTORY! You successfully broke the time loop!");
        } else {
            System.out.println("\n The time loop continues...");
        }
        
        System.out.println(stars);
        System.out.println("Thank you for playing Time Loop Explorers! ***");
    }
    
    private void displayTurn(Explorer e) {
        String equals = "";
        for (int i = 0; i < 50; i++) {
            equals += "=";
        }
        
        System.out.println("\n" + equals);
        System.out.println("  TURN " + turnNumber + " | Room: " + roomNumber);
        System.out.println("Current: " + e.name);
        System.out.println("Next stone: " + nextStone);
        System.out.println("Stones: " + getStonesString(e));
        System.out.println("Direction: " + (forward ? "-> FORWARD" : " <- REVERSE"));
        if (e.hasParadox) System.out.println(" Paradox Shard: AVAILABLE");
    }
    
    private int getChoice(Explorer e) {
        System.out.println("\nAvailable Actions:");
        System.out.println("1. Move to next room");
        System.out.println("2. Use Echo Stone"); 
        System.out.println("3. View Timeline Tree");
        
        if (e.hasParadox) {
            System.out.println("4. Forge New Path (Paradox Shard)");
        }
        
        System.out.println("5. Quit Game");
        System.out.print("Choose action: ");
        
        return getIntInput(1, 5);
    }
    
    private void processChoice(int choice, Explorer e) {
        switch (choice) {
            case 1: 
                move(); 
                break;
            case 2: 
                useStone(e); 
                break;
            case 3: 
                showTimeline(); 
                break;
            case 4: 
                if (e.hasParadox) forgePath(); 
                else System.out.println("You need a Paradox Shard!");
                break;
            case 5: 
                running = false; 
                System.out.println("Exiting game...");
                break;
            default: 
                System.out.println(" Invalid choice!");
        }
    }
    
    private void move() {
        roomNumber++;
        Room newRoom = new Room(roomNumber);
        rooms.add(newRoom);
        
        triggerEvent();
        
        GameState currentState = new GameState(roomNumber, nextStone, forward, turnNumber, 
  lastEventDescription, explorers, rooms, currentExplorer);
        
        String actionDescription = "Turn " + turnNumber + ": " + currentExplorer.data.name + " moved to room " + roomNumber;
        if (lastEventDescription != null && !lastEventDescription.isEmpty()) {
            actionDescription += " . " + lastEventDescription;
            newRoom.setEvent(lastEventDescription);
        }
        
        timeline.addAction(actionDescription, currentExplorer.data, currentState);
    }
    
    private void triggerEvent() {
    int event = rand.nextInt(10); 
    Explorer e = currentExplorer.data;
    lastEventDescription = "";
    
    System.out.println("\n--- Room " + roomNumber + " Event ---");
    
    switch (event) {
        case 0:
            int stone = rand.nextInt(5) + 1;
            System.out.println(" Found Echo Stone " + stone + "!");
            lastEventDescription = "Found Echo Stone " + stone;
            e.addStone(stone);
            break;
       case 1: case 2: case 3:
         System.out.println(" Found Paradox Shard!");
          lastEventDescription = "Found Paradox Shard";
            e.hasParadox = true;
         System.out.println( e.name + " can now manipulate timelines with Forge New Path!");
         break;
        case 4: case 5: case 6: 
            System.out.println(" Trap! -1 HP");
            lastEventDescription = "Trap! -1 HP";
            e.takeDamage();
            if (!e.alive) System.out.println( e.name + " died!");
            break;
        case 7: case 8: 
            System.out.println(" Healing! +1 HP");
            lastEventDescription = "Healing! +1 HP";
            e.heal();
            break;
        case 9: 
            System.out.println(" Found treasure! +1 point");
            lastEventDescription = "Found treasure! +1 point";
            e.treasure++;
            break;
       
    }
    System.out.println("Status: " + e);
}
    
    private void useStone(Explorer e) {
        GameState currentState = new GameState(roomNumber, nextStone, forward, turnNumber, 
             "Used Echo Stone " + nextStone, explorers, rooms, currentExplorer);
        
        if (e.useStone(nextStone)) {
            timeline.addAction(
                "Turn " + turnNumber + ": " + e.name + " used Echo Stone " + nextStone,
                e,
                currentState
            );
            
            System.out.println(" Used Stone " + nextStone);
            nextStone++;
            
            if (nextStone > 5) {
                System.out.println("\n VICTORY! THE TIME LOOP IS BROKEN! ");
                System.out.println("All Echo Stones used in perfect sequence!");
                running = false;
            }
        } else {
            System.out.println(" No Stone " + nextStone);
        }
    }
    
    private void showTimeline() {
        timeline.printTree();
        System.out.println("\nPress Enter to continue"); 
        sc.nextLine();
    }
    
    private void forgePath() {
        System.out.println("\n FORGE NEW PATH ");
        System.out.println(" The Paradox Shard reveals alternate timelines...");
        
        DoubleLinkedList<TimelineNode> allNodes = timeline.getAllNodes();
        
        if (allNodes.isEmpty() || allNodes.size() == 1) {
            System.out.println(" No previous timeline branches available to return to!");
            return;
        }
        
        DoubleNode<TimelineNode> current = allNodes.head;
        int index = 1;
        
        System.out.println("\nAvailable timeline branches:");
        while (current != null && index <= allNodes.size()) {
            String marker = (current.data == timeline.current) ? "  CURRENT" : "";
            System.out.println(index + ". " + current.data.action + " [" + current.data.branchId + "]" + marker);
            current = current.next;
            index++;
        }
        
        System.out.print("\nChoose branch to return to (0 to cancel): ");
        int choice = getIntInput(0, allNodes.size());
        
        if (choice == 0) {
            System.out.println("Timeline manipulation cancelled.");
            return;
        }
        
        current = allNodes.head;
        for (int i = 1; i < choice; i++) {
            current = current.next;
        }
        
        TimelineNode selected = current.data;
        
        if (selected == timeline.current) {
            System.out.println(" You are already in this timeline!");
            return;
        }
        
        timeline.branchTo(selected);
        
        GameState selectedState = selected.state;
        this.roomNumber = selectedState.roomNumber;
        this.nextStone = selectedState.nextStone;
        this.forward = selectedState.forward;
        this.turnNumber = selectedState.turnNumber;
        this.explorers = selectedState.explorers;
        this.rooms = selectedState.rooms;
        this.currentExplorer = selectedState.currentExplorer;
        
        currentExplorer.data.hasParadox = false;
        
        System.out.println("\n REALITY REWRITTEN! Timeline successfully branched!");
        System.out.println(" Now at: " + selected.action);
        System.out.println(" Timeline: " + selected.branchId);
        System.out.println(" All explorer states restored to this point in time");
        System.out.println(" Paradox Shard has been consumed!");
        
        displayTurn(currentExplorer.data);
    }
    
    private void nextTurn() {
        if (forward) {
            currentExplorer = currentExplorer.next;
        } else {
            currentExplorer = currentExplorer.prev;
        }
        
        int attempts = 0;
        while (!currentExplorer.data.alive && attempts < explorers.size()) {
            if (forward) {
                currentExplorer = currentExplorer.next;
            } else {
                currentExplorer = currentExplorer.prev;
            }
            attempts++;
        }
    }
    
    private boolean gameOver() {
        DoubleNode<Explorer> current = explorers.head;
        int checked = 0;
        while (current != null && checked < explorers.size()) {
            if (current.data.alive) return false;
            current = current.next;
            checked++;
        }
        System.out.println("\n  GAME OVER - ALL EXPLORERS HAVE PERISHED ");
        return true;
    }
    
    private String getStonesString(Explorer e) {
        if (e.stones.isEmpty()) return "None";
        StringBuilder sb = new StringBuilder("[");
        DoubleNode<Integer> current = e.stones.head;
        int count = 0;
        while (current != null && count < e.stones.size()) {
            sb.append(current.data);
            if (count < e.stones.size() - 1) sb.append(", ");
            current = current.next;
            count++;
        }
        return sb.append("]").toString();
    }
    
    private int getIntInput(int min, int max) {
        while (true) {
            try {
                int val = Integer.parseInt(sc.nextLine().trim());
                if (val >= min && val <= max) return val;
            } catch (NumberFormatException e) { }
            System.out.print("Please enter a number between " + min + " and " + max + ": ");
        }
    }
   
    public static void main(String[] args) {
         new TimeLoopExplorers().play();
    }
}