/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */
public class Timeline {
    TimelineNode root;
    TimelineNode current;
    
    public Timeline(GameState initialState) {
        this.root = new TimelineNode("Game Start", null, initialState, null);
        this.current = root;
    }
    
    public void addAction(String action, Explorer actor, GameState state) {
        String fullAction = actor.name + " (" + actor.hp + " HP) - " + action;
        
        TimelineNode newNode = new TimelineNode(fullAction, actor, state, current);
        
        current.addChild(newNode); 
        current = newNode;
    }
    
    public void branchTo(TimelineNode target) {
        this.current = target;
    }
    
    public void printTree() {
        int totalBranches = countBranches();
        System.out.println("\n--- TIMELINE TREE (Branching History) ---");
        System.out.println("Current Branch ID: " + current.branchId);
        System.out.println("Total States Saved: " + (totalBranches + 1));
        printNode(root, "", true);
        System.out.println("---------------------------------------\n");
    }
    
    public int countBranches() {
        return countBranchesRecursive(root) - 1;
    }
    
    private int countBranchesRecursive(TimelineNode node) {
        int count = 1;
        DoubleNode<TimelineNode> child = node.children.head;
        int size = node.children.size();
        int checked = 0;
        
        while (child != null && checked < size) {
            count += countBranchesRecursive(child.data);
            child = child.next;
            checked++;
        }
        return count;
    }
    
    private void printNode(TimelineNode node, String prefix, boolean isLast) {
    String connector = isLast ? "`-- " : "|-- ";  
    
    String currentMarker = (node == current) ? " <--- CURRENT" : "";
    
    System.out.print(prefix + connector + "{" + node.branchId + "}");
    System.out.println(node.action + currentMarker);
    
    if (node.state.eventDescription != null && !node.state.eventDescription.isEmpty()) {
        System.out.println(prefix + (isLast ? "   " : "|  ") + " -> " + node.state.eventDescription);
    }
    
    String nextPrefix = prefix + (isLast ? "   " : "|  ");
    
    DoubleNode<TimelineNode> child = node.children.head;
    int totalChildren = node.children.size();
    int childCount = 0;
    
    while (child != null && childCount < totalChildren) {
        boolean childIsLast = (childCount == totalChildren - 1);
        printNode(child.data, nextPrefix, childIsLast);
        child = child.next;
        childCount++;
    }
}
    
    public DoubleLinkedList<TimelineNode> getAllNodes() {
        DoubleLinkedList<TimelineNode> allNodes = new DoubleLinkedList<>();
        collectNodes(root, allNodes);
        return allNodes;
    }
    
    private void collectNodes(TimelineNode node, DoubleLinkedList<TimelineNode> collection) {
        collection.add(node);
        DoubleNode<TimelineNode> child = node.children.head;
        int count = 0;
        int size = node.children.size();
        
        while (child != null && count < size) {
            collectNodes(child.data, collection);
            child = child.next;
            count++;
        }
    }
}