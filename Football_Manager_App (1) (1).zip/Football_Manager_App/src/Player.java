import java.util.*;
public class Player {
    private static int counter = 0;
    private final int backNumber;
    private final String name;
    private final String position;
    private double marketValue;
    private Team currentTeam;
    private Team previousTeam;

    public Player(String name, int backNumber, String position) {
        this.name = name;
        this.backNumber = backNumber;
        this.position = position;
        this.marketValue = 0.0;
    }

    public int getBackNumber() {
        return backNumber;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }

    public Team getCurrentTeam() {
        return currentTeam;
    }

    public void setCurrentTeam(Team currentTeam) {
        this.currentTeam = currentTeam;
    }

    public Team getPreviousTeam() {
        return previousTeam;
    }

    public void setPreviousTeam(Team previousTeam) {
        this.previousTeam = previousTeam;
    }

    @Override
    public String toString() {
        return name + ", backNumber=" + backNumber + ", position=" + position +
                ", marketValue=" + marketValue;
    }
}
