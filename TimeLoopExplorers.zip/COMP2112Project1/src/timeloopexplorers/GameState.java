/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */
public class GameState {
    final int roomNumber, nextStone, turnNumber;
    final boolean forward;
    final String eventDescription;
    final DoubleLinkedList<Explorer> explorers;
    final DoubleLinkedList<Room> rooms;
    final DoubleNode<Explorer> currentExplorer;
    
    public GameState(int room, int stone, boolean fwd, int turn, String eventDesc,
        DoubleLinkedList<Explorer> explorers, DoubleLinkedList<Room> rooms,  DoubleNode<Explorer> currentExplorer) {
        this.roomNumber = room;
        this.nextStone = stone;
        this.forward = fwd;
        this.turnNumber = turn;
        this.eventDescription = eventDesc;
        
        this.explorers = new DoubleLinkedList<>();
        DoubleNode<Explorer> expNode = explorers.head;
        int expCount = 0;
        while (expNode != null && expCount < explorers.size()) {
            this.explorers.add(expNode.data.copy());
            expNode = expNode.next;
            expCount++;
        }
        this.explorers.makeCircular();
        
        this.rooms = new DoubleLinkedList<>();
        DoubleNode<Room> roomNode = rooms.head;
        int roomCount = 0;
        while (roomNode != null && roomCount < rooms.size()) {
            this.rooms.add(roomNode.data.copy());
            roomNode = roomNode.next;
            roomCount++;
        }
        
        this.currentExplorer = findEquivalentExplorer(explorers, currentExplorer, this.explorers);
    }
    
    private DoubleNode<Explorer> findEquivalentExplorer(DoubleLinkedList<Explorer> originalList, 
            
        DoubleNode<Explorer> originalCurrent, DoubleLinkedList<Explorer> newList) {
        
        if (originalCurrent == null || originalList.head == null) return newList.head;
        
        int index = 0;
        DoubleNode<Explorer> temp = originalList.head;
        int originalSize = originalList.size();

        while (temp != originalCurrent && index < originalSize) {
            temp = temp.next;
            index++;
        }

        if (index >= originalSize) {
            return newList.head;
        }

        DoubleNode<Explorer> newCurrent = newList.head;
        for (int i = 0; i < index && newCurrent != null; i++) {
            newCurrent = newCurrent.next;
        }
        
        return newCurrent != null ? newCurrent : newList.head;
    }
}