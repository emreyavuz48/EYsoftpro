public class CircularLinkedList {

    Node head;
    int size;

    public CircularLinkedList() {
        this.head = null;
        this.size = 0;
    }

    public void add(String name) {
        Node newNode = new Node(name);
        if (head == null) {
            head = newNode;
            head.next = head; // Points to itself to make it circular
        } else {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
        }
        size++;
    }

    public void remove(Node prev, Node target) {
        if (target == head) {
            head = head.next;
        }
        prev.next = target.next;
        size--;
    }

    public Node getNode(int k) {
        Node temp = head;
        for (int i = 0; i < k; i++) {
            temp = temp.next;
        }
        return temp;
    }

    public void display(Node a) {
        Node temp = head;
        if(temp==null) return;

        do {
            if (temp == a) {
                System.out.print("[" + temp.getCurrentName() + "] ");
            } else {
                System.out.print(temp.getCurrentName() + " ");
            }
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    public boolean hasOnePlayerLeft() {
        return size == 1;
    }

    public String getWinner() {
        return head.getCurrentName();
    }

}
