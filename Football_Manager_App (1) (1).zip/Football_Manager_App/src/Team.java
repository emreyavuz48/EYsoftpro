import java.util.ArrayList;
import java.util.List;

public class Team {
    private final String shortName;
    private final String fullName;
    private double totalValue;
    private final List<Player> players;
    private static final int MAX_TEAM_SIZE = 22;

    public Team(String shortName, String fullName) {
        this.shortName = shortName;
        this.fullName = fullName;
        this.totalValue = 0.0;
        this.players = new ArrayList<>();
    }

    public String getShortName() {
        return shortName;
    }

    public String getFullName() {
        return fullName;
    }

    public double getTotalValue() {
        return totalValue;
    }

    public void setTotalValue(double totalValue) {
        this.totalValue = totalValue;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void removePlayer(Player player) {
        players.remove(player);
    }

    public int getSize() {
        return players.size();
    }

    @Override
    public String toString() {
        return shortName + ", name=" + fullName + ", totalValue=" + totalValue + ", size=" + getSize();
    }
}
