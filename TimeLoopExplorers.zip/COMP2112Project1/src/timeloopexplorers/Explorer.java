/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timeloopexplorers;

/**
 *
 * @author emreyavuz
 */
public class Explorer {
    final String name;
    int hp, treasure;
    boolean alive, hasParadox;
    DoubleLinkedList<Integer> stones;
    
    public Explorer(String name) {
        this.name = name;
        this.hp = 3;
        this.treasure = 0;
        this.alive = true;
        this.stones = new DoubleLinkedList<>();
        this.hasParadox = false;
    }
    
    public Explorer copy() {
        Explorer copy = new Explorer(this.name);
        copy.hp = this.hp;
        copy.treasure = this.treasure;
        copy.alive = this.alive;
        copy.hasParadox = this.hasParadox;
        
        DoubleNode<Integer> stoneNode = this.stones.head;
        int stoneCount = 0;
        while (stoneNode != null && stoneCount < this.stones.size()) {
            copy.stones.add(stoneNode.data);
            stoneNode = stoneNode.next;
            stoneCount++;
        }
        
        return copy;
    }
    
    public void takeDamage() { 
        hp--; 
        if (hp <= 0) { hp = 0; alive = false; }
    }
    
    public void heal() { 
        if (alive && hp < 3) hp++; 
    }
    
    public void addStone(int num) { stones.add(num); }
    public boolean hasStone(int num) { return stones.contains(num); }
    public boolean useStone(int num) { 
        if (stones.contains(num)) { 
            stones.remove(num); 
            return true; 
        }
        return false;
    }
    
    @Override
    public String toString() {
        return name + " (HP:" + hp + ", Treasure:" + treasure + ")";
    }
}