import java.util.*;
public class SimulateSystem {
    public static void main(String[] args) {
        TransferBoard transferBoard = new TransferBoard();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1- List all Players in the system.");
            System.out.println("2- List all Teams in the system.");
            System.out.println("3- List all teamless players.");
            System.out.println("4- Establish a contract between a player and a team.");
            System.out.println("5- Terminate the existing contract between a player and a team.");
            System.out.println("6- Exit.");
            System.out.print("Choose an action: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.println("\nPlayers in the system:");
                    transferBoard.getPlayers().forEach(System.out::println);
                    break;
                case 2:
                    System.out.println("\nTeams in the system:");
                    transferBoard.getTeams().forEach(System.out::println);
                    break;
                case 3:
                    System.out.println("\nTeamless players:");
                    transferBoard.listTeamlessPlayers();
                    break;
                case 4:
                    System.out.print("\nEnter player name: ");
                    String playerName = scanner.nextLine();
                    System.out.print("Enter team name: ");
                    String teamName = scanner.nextLine();
                    System.out.print("Enter contract type (Permanent/Rented): ");
                    String contractType = scanner.nextLine();
                    System.out.print("Enter contract value: ");
                    double contractValue = scanner.nextDouble();
                    scanner.nextLine(); 
                    System.out.println(transferBoard.makeContract(playerName, teamName, contractType, contractValue));
                    break;
                case 5:
                    System.out.print("\nEnter player name to terminate the contract: ");
                    String terminatePlayerName = scanner.nextLine();
                    System.out.print("Enter team name: ");
                    String terminateTeamName = scanner.nextLine();
                    transferBoard.terminateContract(terminatePlayerName, terminateTeamName);
                    System.out.println("Contract terminated successfully.");
                    break;
                case 6:
                    System.out.println("\nExiting the program...");
                    printSystemInfo(transferBoard);
                    System.exit(0);
                default:
                    System.out.println("\nInvalid choice. Please choose a valid option.");
            }
        }
    }

    private static void printSystemInfo(TransferBoard transferBoard) {
        System.out.println("\nSystem information:");
        System.out.println("Players with contracts:");
        transferBoard.getContracts().forEach(contract ->
                System.out.println(contract.getPlayer().getName() + " : " +
                        contract.getPlayer().getMarketValue() + " " +
                        contract.getPlayer().getCurrentTeam().getShortName()));

        System.out.println("\nTeams:");
        transferBoard.getTeams().forEach(team ->
                System.out.println(team.getShortName() + " : " +
                        team.getTotalValue() + " " +
                        team.getSize()));

        System.out.println("\nPlayers without contracts:");
        transferBoard.listTeamlessPlayers();
    }
}