import java.util.ArrayList;
import java.util.List;

public class TransferBoard {
    private final List<Contract> contracts;
    private final List<Player> players;
    private final List<Team> teams;
    private static final int MAX_TEAM_SIZE = 22;

    public TransferBoard() {
        this.contracts = new ArrayList<>();
        this.players = new ArrayList<>();
        this.teams = new ArrayList<>();
        populatePlayers();
        populateTeams();
    }

    public void populatePlayers() {
        players.add(new Player("Muslera", 1, "Goalkeeper"));
        players.add(new Player("Kaan", 22, "Defence"));
        players.add(new Player("Toreira", 34, "Midfield"));
        players.add(new Player("Icardi", 99, "Forward"));
        players.add(new Player("Kerem", 7, "Midfield"));
        players.add(new Player("Abdulkerim", 17, "Defence"));
        players.add(new Player("Oliveira", 20, "Midfield"));
        players.add(new Player("Mertens", 10, "Midfield"));
        players.add(new Player("Bakambu", 9, "Forward"));
        players.add(new Player("Nellson", 4, "Defence"));
        players.add(new Player("Boey", 2, "Defence"));
    }

    public void populateTeams() {
        teams.add(new Team("Galatasaray", "GS"));
        teams.add(new Team("Fenerbahce", "FB"));
        teams.add(new Team("Besiktas", "BJK"));
        teams.add(new Team("Trabzonspor", "TS"));
        teams.add(new Team("Ankaragucu", "ANK"));
        teams.add(new Team("Basaksehir", "BSK"));
        teams.add(new Team("Karagumruk", "KGM"));
    }

    public String makeContract(String playerName, String teamName, String contractType, double contractValue) {
        Player player = findPlayer(playerName);
        Team team = findTeam(teamName);

        if (player == null) {
            return "UnknownPlayer!";
        }
        if (team == null) {
            return "UnknownTeam!";
        }

        for (Contract contract : contracts) {
            if (contract.getPlayer() == player && contract.getTeam() == team) {
                return "Existing Contract";
            }
        }

        if (team.getPlayers().size() >= getMaxTeamSize()) {
            return "Exceeding Max Num of Players";
        }

        for (Contract contract : contracts) {
            if (contract.getPlayer() == player && contract.getType().equals("Rented")) {
                return "Contract Not Possible";
            }
        }

        if (!contractType.equals("Permanent") && !contractType.equals("Rented")) {
            return "Invalid Contract Type";
        }

        Contract newContract = new Contract(player, team, contractType, contractValue);
        contracts.add(newContract);
        team.addPlayer(player);

        return "Successfully Contracted";
    }

    public void terminateContract(String playerName, String teamName) {
        Player player = findPlayer(playerName);
        Team team = findTeam(teamName);

        if (player == null || team == null) {
            return;
        }

        contracts.removeIf(contract -> contract.getPlayer() == player && contract.getTeam() == team);

        team.removePlayer(player);
    }

    public List<Player> listTeamlessPlayers() {
        List<Player> teamlessPlayers = new ArrayList<>();
        for (Player player : players) {
            if (player.getCurrentTeam() == null) {
                teamlessPlayers.add(player);
            }
        }
        return teamlessPlayers;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public List<Team> getTeams() {
        return teams;
    }

    public List<Contract> getContracts() {
        return contracts;
    }

    private Player findPlayer(String playerName) {
        for (Player player : players) {
            if (player.getName().equals(playerName)) {
                return player;
            }
        }
        return null;
    }

    private Team findTeam(String teamName) {
        for (Team team : teams) {
            if (team.getShortName().equals(teamName)) {
                return team;
            }
        }
        return null;
    }

    private int getMaxTeamSize() {
        return MAX_TEAM_SIZE;
    }
}
