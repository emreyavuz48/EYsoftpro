import java.io.*;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        CityGraph graph = new CityGraph();
        Scanner scanner = new Scanner(System.in);

        try {
            // graph.readGraphFromFile("graph.txt");

            String filePath = CityGraph.class.getClassLoader().getResource("graph.txt").getPath();
            filePath = filePath.replace("%20", " "); // Handle spaces in file paths
            graph.readGraphFromFile(filePath);
            System.out.println("Graph loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading the graph file: " + e.getMessage());
            return;
        }

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Is There A Path");
            System.out.println("2. BFS from To");
            System.out.println("3. What Is Shortest Path Length");
            System.out.println("4. Neighbors");
            System.out.println("5. Highest Degree");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 0) break;

            System.out.print("Enter the first city: ");
            String v1 = scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter the second city: ");
                    String v2 = scanner.nextLine();
                    System.out.println("Path exists: " + graph.isThereAPath(v1, v2));
                    break;
                case 2:
                    System.out.print("Enter the second city: ");
                    v2 = scanner.nextLine();
                    graph.bfsFromTo(v1, v2);
                    break;
                case 3:
                    System.out.print("Enter the second city: ");
                    v2 = scanner.nextLine();
                    int length = graph.whatIsShortestPathLength(v1, v2);
                    if (length != -1) {
                        System.out.println("Shortest path length: " + length);
                    }
                    break;
                case 4:
                    System.out.println("Neighbors: " + graph.neighbors(v1));
                    break;
                case 5:
                    System.out.println("Cities with highest degree: " + graph.highestDegree());
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }

        scanner.close();
    }
}