public class Contract {
    private final Player player;
    private final Team team;
    private final String type;
    private final double value;

    public Contract(Player player, Team team, String type, double value) {
        this.player = player;
        this.team = team;
        this.type = type;
        this.value = value;
    }

    public Player getPlayer() {
        return player;
    }

    public Team getTeam() {
        return team;
    }

    public String getType() {
        return type;
    }

    public double getValue() {
        return value;
    }
}
