/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banking.simulation;

import java.util.*;

public class FinancialPortfolio {
    private List<Account> accounts;

    public FinancialPortfolio() {
        this.accounts = new ArrayList<>();
    }

    public void addAccount(Account account) {
        accounts.add(account);
    }

    public void removeAccount(Account account) {
        accounts.remove(account);
    }

    public double calculateTotalValue() {
        double totalValue = 0;
        for (Account account : accounts) {
            totalValue += account.getBalance();
        }
        return totalValue;
    }

    public void printAccountInformation() {
        for (Account account : accounts) {
            System.out.println(account);
        }
    }

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

}